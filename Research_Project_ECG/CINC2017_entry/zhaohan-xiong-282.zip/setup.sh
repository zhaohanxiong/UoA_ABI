#! /bin/bash

set -e
set -o pipefail

chmod a+x challenge.py