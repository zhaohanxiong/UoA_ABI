#! /bin/bash

set -e
set -o pipefail

RECORD=$1

./challenge.py $RECORD